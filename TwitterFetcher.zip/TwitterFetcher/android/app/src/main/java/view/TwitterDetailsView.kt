package view

import android.annotation.TargetApi
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ScaleDrawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.example.dragos.myapplication.R
import model.TwitterProfile

class TwitterDetailsView : LinearLayout {

    constructor(context: Context) : super(context) {
        LayoutInflater.from(context).inflate(R.layout.twitter_details_view, this, true)
    }

    fun setProfile(profile: TwitterProfile) {
        val name = findViewById<TextView>(R.id.twitterName)
        name.text = profile.name

        val lastTweet = findViewById<TextView>(R.id.lastTweet)
        lastTweet.text = profile.lastTweet
    }
}