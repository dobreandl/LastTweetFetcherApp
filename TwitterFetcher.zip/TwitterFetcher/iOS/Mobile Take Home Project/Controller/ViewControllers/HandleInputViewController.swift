//
//  HandleInputViewController.swift
//  Mobile Take Home Project
//
//  Created by Dragos Dobrean on 22/01/2021.
//

import UIKit

protocol HandleInputFlowDelegate: class {
    func handleInputShowResults(viewController: HandleInputViewController, handle: String)
}

class HandleInputViewController: UIViewController {
    
    weak var flowDelegate: HandleInputFlowDelegate?

    @IBOutlet weak var handleTextField: UITextField!
    @IBOutlet weak var seeDetailsButton: UIButton!
    

    // MARK: Actions

    @IBAction func seeDetailsTapped(_ sender: Any) {
        guard let text = handleTextField.text, text.count > 1 else {
            return
        }
        
        flowDelegate?.handleInputShowResults(viewController: self, handle: text)
    }
}

