//
//  TwitterService.swift
//  Mobile Take Home Project
//
//  Created by Dragos Dobrean on 22/01/2021.
//

import Foundation

public typealias JSONClosure = (_ success: Bool, _ json: [String: Any]?) -> Void

typealias TwitterProfileCompletion = (_ success: Bool, _ profile: TwitterProfile?) -> Void

class TwitterService: NSObject {
    
    private let mapper = TwitterAPIMapper()
    
    private struct Constants {
        struct Authentication {
            static let bearerToken = "Bearer AAAAAAAAAAAAAAAAAAAAAAUMMAEAAAAAxR4KNz6Xs4iImfDCIy0Pid3O71M%3DkoKacPemL2YKxQQbcgD42TfdadMZW2SjuujklkoHN6Q05djubB"
        }
        
        struct Endpoint {
            static let twitterAPIEndpoint = "https://api.twitter.com/1.1/"
            
            static let getProfile = twitterAPIEndpoint + "users/show.json"
        }
    }
    
    // MARK: Methods
    
    func getUserProfile(username: String, completion: @escaping TwitterProfileCompletion) {
        var urlComponents = URLComponents(string: Constants.Endpoint.getProfile)
        urlComponents?.queryItems = [URLQueryItem(name: "screen_name", value: username)]
        
        guard let url = urlComponents?.url else {
            return
        }
        
        let request = getTwitterAPIRequest(url: url)
        
        makeRequest(URLRequest: request) { (success, response) in
            guard success,
                  let response = response,
                  !self.mapper.hasError(response: response),
                  let profile = self.mapper.parseProfile(response: response) else {
                
                completion(false, nil)
                return
            }
            
            completion(true, profile)
        }
    }
    
    // MARK: Private methods
    
    private func getTwitterAPIRequest(url: URL) -> URLRequest {
        var urlRequest = URLRequest(url: url)
        urlRequest.setValue(Constants.Authentication.bearerToken, forHTTPHeaderField: "authorization")
        
        return urlRequest
    }
    
    
    
    private let config = URLSessionConfiguration.default
    private var session: URLSession!
    
    // MARK: Lifecycle
    
    override init() {
        super.init()
        
        session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
    }
    
    // MARK: Methods
    
    func makeRequest(URLRequest: URLRequest, completion: @escaping JSONClosure) {
        let task = session.dataTask(with: URLRequest) { (data, urlResponse, error) in
            guard error == nil, let data = data else {
                return
            }
            
            do {
                if let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] {
                    DispatchQueue.main.async {
                        // Success
                        completion(true, json)
                    }
                    return
                }
                
            } catch _ {}
            
            DispatchQueue.main.async {
                // failure
                completion(false, nil)
            }
        }
        
        task.resume()
    }
}
