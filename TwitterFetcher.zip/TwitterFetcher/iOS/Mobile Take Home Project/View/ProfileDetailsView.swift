//
//  ProfileDetailsView.swift
//  Mobile Take Home Project
//
//  Created by Dragos Dobrean on 31/01/2021.
//

import UIKit

class ProfileDetailsView: UIView {
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var tweetTextLabel: UILabel!

    
    static func loadView() -> ProfileDetailsView {
        let view = Bundle.main.loadNibNamed("ProfileDetailsView", owner: self, options: nil)![0] as! ProfileDetailsView
        
        
        return view
    }
    
    
    func set(profile: TwitterProfile) {
        usernameLabel.text = profile.username
        tweetTextLabel.text = profile.lastTweet ?? "No tweets"
    }
}
