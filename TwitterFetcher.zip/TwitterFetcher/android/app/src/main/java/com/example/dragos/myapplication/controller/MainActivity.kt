package com.example.dragos.myapplication.controller

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.Fragment
import com.example.dragos.myapplication.R
import com.example.dragos.myapplication.controller.fragments.HandleInputFragment
import com.example.dragos.myapplication.controller.fragments.TwitterDetailsFragment

class MainActivity : AppCompatActivity(), HandleInputFragment.HandleInputListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val handleFragment = HandleInputFragment()
        setFragment(handleFragment, "handle")
    }


    // MARK: Private methods

    private fun setFragment(fragment: Fragment, tag: String) {
        supportFragmentManager.beginTransaction()
                .setCustomAnimations(android.R.anim.slide_out_right, android.R.anim.slide_out_right, android.R.anim.slide_in_left, android.R.anim.slide_out_right)
                .replace(R.id.fragmentContainer, fragment, tag)
                .commit()
    }

    private fun displayFragment(fragment: Fragment, tag: String) {
        supportFragmentManager.beginTransaction()
                .setCustomAnimations(android.R.anim.slide_out_right, android.R.anim.slide_out_right, android.R.anim.slide_in_left, android.R.anim.slide_out_right)
                .replace(R.id.fragmentContainer, fragment, tag)
                .addToBackStack(tag)
                .commit()
    }

    // MARK: Handle input

    override fun handleDisplayDetails(handle: String) {
        val detailsFragment = TwitterDetailsFragment()
        detailsFragment.handle = handle

        displayFragment(detailsFragment, "details")
    }

}
