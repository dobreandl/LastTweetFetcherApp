package com.example.dragos.myapplication.controller.fragments

import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView

import com.example.dragos.myapplication.R


class HandleInputFragment : Fragment() {

    private var listener: HandleInputListener? = null

    // MARK: Lifecycle

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment

        val view = inflater.inflate(R.layout.fragment_handle_input, container, false)
        val textView = view.findViewById<TextView>(R.id.handleText)

        var button = view.findViewById<Button>(R.id.button)

        button.setOnClickListener {
            handleButtonPressed(textView.text.toString())
        }


        return view
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is HandleInputListener) {
            listener = context
        } else {
            throw RuntimeException(context.toString() + " must implement OnFragmentInteractionListener")
        }
    }

    override fun onDetach() {
        super.onDetach()

        listener = null
    }

    // MARK: Private methods

    private fun handleButtonPressed(text: String?) {
        if (text != null && text.length > 3) {
            listener?.handleDisplayDetails(text)
        }
    }


    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     *
     *
     * See the Android Training lesson [Communicating with Other Fragments]
     * (http://developer.android.com/training/basics/fragments/communicating.html)
     * for more information.
    */
    interface HandleInputListener {
        fun handleDisplayDetails(handle: String)
    }

}
