//
//  ProfileDetailsViewController.swift
//  Mobile Take Home Project
//
//  Created by Dragos Dobrean on 22/01/2021.
//

import UIKit

class ProfileDetailsViewController: UIViewController {
    
    // This needs to be set
    var username: String!

    @IBOutlet weak var stackView: UIStackView!
    var profileDetails = ProfileDetailsView.loadView()
    var profileError = ProfileErrorView.loadView()

    
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    
    private let service = TwitterService()
    
    // MARK: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchUserProfile()
        
        stackView.addSubview(profileDetails)
        stackView.addSubview(profileError)
        
        profileDetails.isHidden = true
        profileError.isHidden = true
    }
    
    // MARK: Private methods

    private func fetchUserProfile() {
        // Check if username was set
        guard username != nil else {
            showError()
            
            return
        }
        
        activityIndicatorView.startAnimating()
        
        service.getUserProfile(username: username) {[weak self] (success, profile) in
            self?.activityIndicatorView.stopAnimating()
            
            guard let profile = profile, success else {
                self?.showError()
                return
            }
            
            self?.profileError.isHidden = true
            self?.profileDetails.isHidden = false
            self?.profileDetails.set(profile: profile)
        }
    }
    
    private func showError() {
        profileDetails.isHidden = true
        profileError.isHidden = false
    }
}
