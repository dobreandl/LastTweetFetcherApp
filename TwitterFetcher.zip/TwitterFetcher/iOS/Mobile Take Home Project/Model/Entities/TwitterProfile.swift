//
//  TwitterProfile.swift
//  Mobile Take Home Project
//
//  Created by Dragos Dobrean on 22/01/2021.
//

import Foundation

struct TwitterProfile {
    let username: String
    let photoURL: URL?
    let lastTweet: String?
}
