//
//  AppCoordinator.swift
//  Mobile Take Home Project
//
//  Created by Dragos Dobrean on 22/01/2021.
//

import UIKit

class AppCoordinator {
    
    private struct Constants {
        static let storyboardName = "Main"
        
        static let handlerInputIdentifier = "handle_input"
        static let profileDetailsIdentifier = "profile_details"
    }
    
    private let navigationController = UINavigationController()
    
    
    // Returns the root view controller of the app
    func startApp() -> UIViewController {
        startTwitterHandlerInput()
        
        return navigationController
    }
    
    
    // MARK: Private methods
    
    private func startTwitterHandlerInput() {
        guard let vc = getViewControllerWith(identifier: Constants.handlerInputIdentifier) as? HandleInputViewController else {
            
            return
        }
        
        vc.flowDelegate = self
        navigationController.viewControllers = [vc]
    }
    
    private func navigateToProfileDetails(username: String) {
        guard let vc = getViewControllerWith(identifier: Constants.profileDetailsIdentifier) as? ProfileDetailsViewController else {
            
            return
        }
        
        vc.username = username
        navigationController.pushViewController(vc, animated: true)
    }
    
    private func getViewControllerWith(identifier: String) -> UIViewController {
        let storyboard = UIStoryboard(name: Constants.storyboardName, bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: identifier)
        
        return vc
    }
}

extension AppCoordinator: HandleInputFlowDelegate {
    func handleInputShowResults(viewController: HandleInputViewController, handle: String) {
        navigateToProfileDetails(username: handle)
    }
}
