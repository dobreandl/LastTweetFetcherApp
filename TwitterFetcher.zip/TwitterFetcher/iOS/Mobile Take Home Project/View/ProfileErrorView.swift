//
//  ProfileErrorView.swift
//  Mobile Take Home Project
//
//  Created by Dragos Dobrean on 31/01/2021.
//

import UIKit

class ProfileErrorView: UIView {

    
    static func loadView() -> ProfileErrorView {
        let view = Bundle.main.loadNibNamed("ProfileErrorView", owner: self, options: nil)![0] as! ProfileErrorView
        
        return view
    }


}
