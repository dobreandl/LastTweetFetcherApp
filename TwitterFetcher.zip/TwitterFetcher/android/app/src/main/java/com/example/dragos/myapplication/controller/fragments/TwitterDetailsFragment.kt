package com.example.dragos.myapplication.controller.fragments

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout

import com.example.dragos.myapplication.R
import model.TwitterProfile
import model.TwitterResultHandler
import model.TwitterService
import view.TwitterDetailsView
import view.TwitterErrorView


class TwitterDetailsFragment : Fragment() {

    var handle: String? = null

    private val service = TwitterService()



    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment

        val view = inflater.inflate(R.layout.fragment_twitter_details, container, false)

        val linearLayout = view.findViewById<LinearLayout>(R.id.linearLayout)

        val details = TwitterDetailsView(context!!)

        val errorView = TwitterErrorView(context!!)

        val responseHandler = object : TwitterResultHandler {
            override fun onSuccess(profile: TwitterProfile) {
                linearLayout.addView(details)
                details.setProfile(profile)
            }

            override fun onFailure() {
                // getting data failed for some reason
                linearLayout.addView(errorView)
            }
        }

        service.getProfile(context!!, handle!!, responseHandler)



        return view
    }


}
