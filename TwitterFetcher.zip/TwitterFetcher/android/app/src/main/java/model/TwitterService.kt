package model

import android.content.Context
import android.util.Log
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley


interface TwitterResultHandler {
    fun onSuccess(profile: TwitterProfile)
    fun onFailure()
}

class TwitterService {


    fun getProfile(context: Context, handle: String, responseHandler: TwitterResultHandler) {
        val path = "https://api.twitter.com/1.1/users/show.json?screen_name=" + handle
        val queue = Volley.newRequestQueue(context)

        val request = object : JsonObjectRequest(Request.Method.GET, path, null,
                Response.Listener {
                    // Success Part
                    var name = it.getString("name")
                    var text: String? = null

                    if (it.has("status")) {
                        var status = it.getJSONObject("status")
                        if (status.has("text")) {
                            text = status.getString("text")
                        }
                    }

                    val profile = TwitterProfile(name, text)
                    responseHandler.onSuccess(profile)
                },

                Response.ErrorListener {
                    // Failure Part
                    responseHandler.onFailure()
                }
        ) {
            // Providing Request Headers

            override fun getHeaders(): Map<String, String> {
                // Create HashMap of your Headers as the example provided below

                val headers = HashMap<String, String>()
                headers["Authorization"] = "Bearer AAAAAAAAAAAAAAAAAAAAAAUMMAEAAAAAxR4KNz6Xs4iImfDCIy0Pid3O71M%3DkoKacPemL2YKxQQbcgD42TfdadMZW2SjuujklkoHN6Q05djubB"

                return headers
            }
        }

        queue.add(request)
    }

}