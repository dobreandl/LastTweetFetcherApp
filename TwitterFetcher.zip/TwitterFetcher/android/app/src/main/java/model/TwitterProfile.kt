package model

class TwitterProfile(val name: String,
                     val lastTweet: String?) {

}