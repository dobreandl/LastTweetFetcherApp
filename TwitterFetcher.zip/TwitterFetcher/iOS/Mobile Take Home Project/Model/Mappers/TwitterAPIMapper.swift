//
//  TwitterAPIMapper.swift
//  Mobile Take Home Project
//
//  Created by Dragos Dobrean on 22/01/2021.
//

import Foundation

class TwitterAPIMapper {
    
    private struct Constants {
        static let screenName = "name"
        static let photoURL = "profile_image_url_https"
        static let errors = "errors"
        
        static let status = "status"
        static let text = "text"
    }
    
    // MARK: Methods
    
    func hasError(response: [String: Any]) -> Bool {
        if response[Constants.errors] != nil {
            return true
        }
        
        return false
    }
    
    func parseProfile(response: [String: Any]) -> TwitterProfile? {
        guard let username = response[Constants.screenName] as? String else {
            return nil
        }
        
        var photoURL: URL?
        if let photoURLString = response[Constants.photoURL] as? String {
            // user original photo size https://developer.twitter.com/en/docs/twitter-api/v1/accounts-and-users/user-profile-images-and-banners
            photoURL = URL(string: photoURLString.replacingOccurrences(of: "_normal", with: ""))
        }
        
        let tweet = parseTweetFromProfile(response: response)

        return TwitterProfile(username: username, photoURL: photoURL, lastTweet: tweet)
    }
    
    
    // MARK: Private methods
    
    private func parseTweetFromProfile(response: [String: Any]) -> String? {
        guard let statusDict = response[Constants.status] as? [String: Any],
              let text = statusDict[Constants.text] as? String else {
            
            return nil
        }
        
        return text
    }
}
