package view

import android.content.Context
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import com.example.dragos.myapplication.R

class TwitterErrorView : LinearLayout {

    constructor(context: Context) : super(context) {
        LayoutInflater.from(context).inflate(R.layout.twitter_error_view, this, true)
    }
}